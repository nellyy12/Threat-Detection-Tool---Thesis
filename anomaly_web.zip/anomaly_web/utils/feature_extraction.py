# utils/feature_extraction.py

import pandas as pd

def extract_features_from_logs(session_data):
    """
    Converts raw session_data dictionary into a DataFrame with engineered features.
    """
    df = pd.DataFrame(session_data).T.reset_index(drop=True)

    # Compute derived numeric features
    df['num_pages'] = df['pages_visited'].apply(lambda x: len(x) if isinstance(x, list) else 0)
    df['num_inputs'] = df['input_logs'].apply(lambda x: len(x) if isinstance(x, list) else 0)

    return df

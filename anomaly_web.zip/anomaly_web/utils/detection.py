# utils/detection.py

import json
import joblib
import pandas as pd
from utils.feature_extraction import extract_features_from_logs

# Load trained model, encoder, and scaler
model = joblib.load("model/anomaly_detector.pkl")
encoder = joblib.load("model/encoder.pkl")
scaler = joblib.load("model/scaler.pkl")

# Define columns
cat_cols = ['browser', 'os', 'device_type']
num_cols = ['session_duration', 'num_pages', 'num_inputs']

def get_anomaly_results():
    # Load logs from file
    with open("data/session_logs.json") as f:
        session_data = json.load(f)

    # Extract raw DataFrame and features
    df = extract_features_from_logs(session_data)

    # Handle missing columns gracefully
    for col in cat_cols + num_cols:
        if col not in df.columns:
            df[col] = "Unknown" if col in cat_cols else 0

    # One-hot encode categorical features
    encoded_cat = encoder.transform(df[cat_cols]).toarray()
    encoded_df = pd.DataFrame(encoded_cat, columns=encoder.get_feature_names_out(cat_cols))

    # Combine numeric and encoded features
    numeric_df = df[num_cols].reset_index(drop=True)
    feature_df = pd.concat([numeric_df, encoded_df.reset_index(drop=True)], axis=1)

    # Scale final feature set
    scaled = scaler.transform(feature_df)

    # Run prediction
    preds = model.predict(scaled)
    scores = model.decision_function(scaled)

    # Format results
    results = []
    for i, (row, pred, score) in enumerate(zip(df.to_dict(orient="records"), preds, scores)):
        results.append({
            "session_id": row.get("session_id", f"sess_{i+1}"),
            "username": row.get("user_id", "N/A"),
            "timestamp": row.get("login_time", "N/A"),
            "prediction": "Anomaly" if pred == -1 else "Normal",
            "score": round(score, 4)
        })

    return results
